package com.example.hrmanagaementakash;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.*;

public class HelloController {
    public TextField username;
    public PasswordField password;
    public Label errorMessage;
    @FXML
    private Label welcomeText;

    @FXML
    public void login(javafx.event.ActionEvent actionEvent) {

        {
            try {
                Parent secondScene = FXMLLoader.load(getClass().getResource("dashboard.fxml"));

                Stage secondStage = new Stage();
                secondStage.setTitle("Dashboard");
                secondStage.setScene(new Scene(secondScene));
                Stage firstSceneStage = (Stage) username.getScene().getWindow();

                firstSceneStage.close();


                secondStage.show();
            } catch (IOException e) {
                e.printStackTrace();

            }
        }}}


